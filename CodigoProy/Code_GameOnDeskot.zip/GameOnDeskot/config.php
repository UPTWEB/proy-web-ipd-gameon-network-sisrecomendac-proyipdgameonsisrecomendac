<?php
// Cambia este valor si tu proyecto está en otra carpeta o en producción
define('BASE_URL', '');
?>